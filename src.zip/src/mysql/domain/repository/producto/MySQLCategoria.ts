export interface MysqlCategoria {
    idCategoria: number;
    nombreCategoria: string;
    tipo: number;
}
