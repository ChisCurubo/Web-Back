export interface MysqlTipoProducto {
    idTipoProducto: number;
    nombreTipoProducto: string;
}
