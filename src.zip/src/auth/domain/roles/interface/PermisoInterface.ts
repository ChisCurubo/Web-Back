export interface Permiso {
    idPermiso: number;
    nombrePermiso: string;
    descripcionPermiso: string;
    }