export interface TipoProducto {
  idTipoProducto: number;
  nombreTipoProducto: string;
}
