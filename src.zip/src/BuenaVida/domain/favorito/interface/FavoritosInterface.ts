import AbstractProducto from "../../producto/AbstractTypes/AbstractProducto";



export interface Favoritos {
  idProducto: AbstractProducto[];
}
