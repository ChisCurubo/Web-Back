export interface Descuento {
  idDescuento: number;
  nombreDescuento: string;
  estadoDescuento: boolean;
}