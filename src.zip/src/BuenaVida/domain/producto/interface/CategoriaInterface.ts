export interface Categoria {
  idCategoria: number;
  nombreCategoria: string;
  descripcion: string ;
}