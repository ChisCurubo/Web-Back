

export interface FiltrarProducto {
  tallaProducto?: string ;
  precioProductoMin?: number;
  precioProductoMax?: number;
  categoria_id?: string ;
  descuento_id?: boolean;
}