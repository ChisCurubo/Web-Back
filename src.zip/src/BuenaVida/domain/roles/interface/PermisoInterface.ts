export interface Permiso {
    idPermiso: number;
    nombrePermiso: string;
    tipo: string;
    estadoPermiso: boolean;
    }