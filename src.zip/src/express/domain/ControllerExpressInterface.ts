export default interface ControllerExpressInterface {
  
}